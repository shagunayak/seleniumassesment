package Base_class;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Shopping_Cart {
	WebDriver dr;
	By xp=By.xpath("/html/body/table[2]/tbody/tr/td/a[1]");
	By xp1=By.xpath("//table[@class=\"Grid\"]/tbody/tr[2]/td[1]");
	By xp2=By.xpath("//table[@class=\"Grid\"]/tbody/tr[3]/td[1]");
	By xp3=By.xpath("//table[@class=\"Grid\"]/tbody/tr[2]/td[4]");
	By xp4=By.xpath("//table[@class=\"Grid\"]/tbody/tr[3]/td[4]");
	ArrayList<String> arr1;
	ArrayList<WebElement> arr3;
	public Shopping_Cart(WebDriver dr)
	{
		this.dr=dr;
	}
	public void go_back_home()
	{
		WebDriverWait wt = new WebDriverWait(dr,10);                             
		wt.until(ExpectedConditions.elementToBeClickable(xp));
		dr.findElement(xp).click();
		
	}
	public ArrayList<String> verify_product()
	{
		arr1=new ArrayList();
		arr3=new ArrayList();
		WebDriverWait wt = new WebDriverWait(dr,10);                             
		wt.until(ExpectedConditions.elementToBeClickable(xp1));
		arr3.add(dr.findElement(xp1));
		arr3.add(dr.findElement(xp2));
		for(WebElement we:arr3)
		{
			arr1.add(we.getText());
		}
		return arr1;
	}
	public ArrayList<String> verify_price()
	{
		arr1=new ArrayList();
		arr3=new ArrayList();
		WebDriverWait wt = new WebDriverWait(dr,10);                             
		wt.until(ExpectedConditions.elementToBeClickable(xp3));
		arr3.add(dr.findElement(xp3));
		arr3.add(dr.findElement(xp4));
		for(WebElement we:arr3)
		{
			String s=we.getText();
			int i=s.indexOf('$');
			String s2=s.substring(i+1);
			arr1.add(s2);
		}
		return arr1;
	}
}
