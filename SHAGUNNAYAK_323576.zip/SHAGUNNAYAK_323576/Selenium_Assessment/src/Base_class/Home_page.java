package Base_class;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Home_page {
	WebDriver dr;
	By xp=By.xpath("//form[@name=\"products_search\"]/table/tbody/tr/th");
	By xp1=By.xpath("//table[@class=\"Record\"]/tbody/tr/td/select");
	By xp2=By.xpath("//table[@class=\"Record\"]/tbody/tr/td/input");
	By xp3=By.xpath("/html/body/table[5]/tbody/tr/td[1]/form/table[2]/tbody/tr[3]/td/input");
	public Home_page(WebDriver dr)
	{
		this.dr=dr;
	}
	public String title()
	{
		return dr.getTitle();
	}
	public String search_product()
	{
		WebDriverWait wt = new WebDriverWait(dr,10);                             
		wt.until(ExpectedConditions.elementToBeClickable(xp));
		return dr.findElement(xp).getText();
	}
	public void search(String s1, String s2)
	{
		WebDriverWait wt = new WebDriverWait(dr,10);                             
		wt.until(ExpectedConditions.elementToBeClickable(xp1));
		dr.findElement(xp1).sendKeys(s1);
		dr.findElement(xp2).sendKeys(s2);
		dr.findElement(xp3).click();
	}
}
