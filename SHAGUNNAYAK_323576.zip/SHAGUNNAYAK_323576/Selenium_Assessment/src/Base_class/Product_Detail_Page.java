package Base_class;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Product_Detail_Page {
	WebDriver dr;
	By xp=By.xpath("/html/body/table[5]/tbody/tr/td/form/form/p[1]/input");
	By xp1=By.xpath("/html/body/table[5]/tbody/tr/td/form/form/p[2]/input[1]");
	public Product_Detail_Page(WebDriver dr)
	{
		this.dr=dr;
	}
	public String title()
	{
		return dr.getTitle();
	}
	public void entry1(String s)
	{
		WebDriverWait wt = new WebDriverWait(dr,10);                             
		wt.until(ExpectedConditions.elementToBeClickable(xp1));
		dr.findElement(xp).clear();
		dr.findElement(xp).sendKeys(s);
		dr.findElement(xp1).click();
	}
	
}
