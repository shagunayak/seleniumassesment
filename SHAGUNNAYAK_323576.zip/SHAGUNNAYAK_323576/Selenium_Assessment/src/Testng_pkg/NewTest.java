package Testng_pkg;

import java.util.ArrayList;
import java.util.Iterator;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Base_class.Home_page;
import Base_class.Product_Detail_Page;
import Base_class.Search_Result_Page;
import Base_class.Shopping_Cart;
import Base_class.read_write;


public class NewTest {
	WebDriver dr;
	Home_page hp;
	Logger log;
	Search_Result_Page srp;
	Product_Detail_Page pdp;
	Shopping_Cart sc;
	read_write rw=new read_write();
	ArrayList<String> arr1=new ArrayList();
	ArrayList<String> arr2;
	ArrayList<String> arr3=new ArrayList();
	ArrayList<String> arr4;
	int i=0;
	int j=0;
	String s1=rw.read(2, 0, "C:\Users\arnav.patra\Desktop\ArnavPatra_323562\Selenium_Assessment\Result\assessment.xlsx", "Sheet1");
	String s2=rw.read(2, 1, "C:\Users\arnav.patra\Desktop\ArnavPatra_323562\Selenium_Assessment\Result\assessment.xlsx", "Sheet1");
	String s3=rw.read1(2, 2, "C:\Users\arnav.patra\Desktop\ArnavPatra_323562\Selenium_Assessment\Result\assessment.xlsx", "Sheet1");
	String s4=rw.read(3, 0, "C:\Users\arnav.patra\Desktop\ArnavPatra_323562\Selenium_Assessment\Result\assessment.xlsx", "Sheet1");
	String s5=rw.read(3, 1, "C:\Users\arnav.patra\Desktop\ArnavPatra_323562\Selenium_Assessment\Result\assessment.xlsx", "Sheet1");
	String s6=rw.read1(3, 2, "C:\Users\arnav.patra\Desktop\ArnavPatra_323562\Selenium_Assessment\Result\assessment.xlsx", "Sheet1");
	String s7=rw.read(2, 0, "C:\Users\arnav.patra\Desktop\ArnavPatra_323562\Selenium_Assessment\Result\assessment.xlsx", "Sheet2");
	String s8=rw.read(3, 0, "C:\Users\arnav.patra\Desktop\ArnavPatra_323562\Selenium_Assessment\Result\assessment.xlsx", "Sheet2");
	String s9=rw.read2(2, 1, "C:\Users\arnav.patra\Desktop\ArnavPatra_323562\Selenium_Assessment\Result\assessment.xlsx", "Sheet2");
	String s10=rw.read2(3, 1, "C:\Users\arnav.patra\Desktop\ArnavPatra_323562\Selenium_Assessment\Result\assessment.xlsx", "Sheet2");
	 @BeforeClass
	  public void entry() 
	 {
		   System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		   dr=new ChromeDriver();
		   dr.get("http://examples.codecharge.com/Store/Default.php"); 
		   arr2=new ArrayList();
		   arr2.add(s7);
		   arr2.add(s8);
		   arr4=new ArrayList();
		   arr4.add(s9);
		   arr4.add(s10);
	  }
	  @AfterClass
	  public void exit()
	  {
		  dr.quit();
	  }
	  @Test(priority=2)
	  public void search1()
	  {
		  hp=new Home_page(dr);
		  hp.search(s1,s2);
		  String result="";
		  rw.create_log("search", s1, s2, result);
	  }
	  @Test(priority=3)
	  public void verify_title1()
	  {
		  srp=new Search_Result_Page(dr);
		  String s1=srp.title();
		  Assert.assertEquals(s1,"SearchResults");
		  String result="Pass";
		  rw.create_log("title", s1, s2, result);
	  }
	  @Test(priority=4)
	  public void click()
	  {
		  srp=new Search_Result_Page(dr);
		  srp.click();
		  String result="";
		  rw.create_log("Click", s1, s2, result);
	  }
	  @Test(priority=5)
	  public void verify_title2()
	  {
		  pdp=new Product_Detail_Page(dr);
		  String s1=pdp.title();
		  Assert.assertEquals(s1, "ProductDetail");
		  String result="Pass";
		  rw.create_log("title", s1, s2, result);
	  }
	  @Test(priority=6)
	  public void enter()
	  {
		  pdp=new Product_Detail_Page(dr);
		  pdp.entry1(s3);
		  String result="";
		  rw.create_log("entry", s1, s2, result);
	  }
	  @Test(priority=7)
	  public void search2()
	  {
		  sc=new Shopping_Cart(dr);
		  sc.go_back_home();
		  hp=new Home_page(dr);
		  hp.search(s4,s5);
		  String result="";
		  rw.create_log("search", s1, s2, result);
	  }
	  @Test(priority=8)
	  public void click1()
	  {
		  srp=new Search_Result_Page(dr);
		  srp.click();
		  String result="";
		  rw.create_log("Click", s1, s2, result);
	  }
	  @Test(priority=9)
	  public void enter1()
	  {
		  pdp=new Product_Detail_Page(dr);
		  pdp.entry1(s6);
		  String result="";
		  rw.create_log("entry1", s1, s2, result);
	  }
	  @Test(priority=11 ,dataProvider="product")
	  public void products(String s)
	  {
		  String s1=s;
		  String s2=arr2.get(i);
		  Assert.assertEquals(s1, s2);
		  i++;
		  String result="Pass";
		  rw.create_log("Verify_product", s1, s2, result);
		  
	  }
	  @DataProvider(name="product")
	  public Iterator<String> get_data()
	  {
		  sc=new Shopping_Cart(dr);
		  arr1=sc.verify_product();
		  return arr1.iterator();
	  }
	  @Test(priority=12 ,dataProvider="price")
	  public void prices(String s)
	  {
		  String s1=s;
		  String s2=arr4.get(j);
		  Assert.assertEquals(s1, s2);
		  j++;
		  String result="Pass";
		  rw.create_log("Verify_price", s1, s2, result);
		  
	  }
	  @DataProvider(name="price")
	  public Iterator<String> get_data1()
	  {
		  sc=new Shopping_Cart(dr);
		  arr3=sc.verify_price();
		  return arr3.iterator();
	  }
}
