package Base_class;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class read_write {
	Logger log;
	public String read(int x, int y ,String file_path,String sheet )
	{
		String result=null;
		try
		{
			File f = new File(file_path);
			FileInputStream  fis = new FileInputStream(f);
			XSSFWorkbook wb =  new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet(sheet);
			XSSFRow row = sh.getRow(x);
			XSSFCell cell = row.getCell(y);
			result = cell.getStringCellValue();
			
		}
		catch(Exception e)
		{
			System.out.println(e);
			System.out.println("not reading");
		}
		
		return result;
	
	}
	public String read1(int x, int y ,String file_path ,String sheet)
	{
		String result=null;
		try
		{
			File f = new File(file_path);
			FileInputStream  fis = new FileInputStream(f);
			XSSFWorkbook wb =  new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet(sheet);
			XSSFRow row = sh.getRow(x);
			XSSFCell cell = row.getCell(y);
			result = Integer.toString((int)(cell.getNumericCellValue()));
			
		}
		catch(Exception e)
		{
			System.out.println(e);
			System.out.println("not reading");
		}
		
		return result;
	
	}
	public String read2(int x, int y ,String file_path ,String sheet)
	{
		String result=null;
		try
		{
			File f = new File(file_path);
			FileInputStream  fis = new FileInputStream(f);
			XSSFWorkbook wb =  new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet(sheet);
			XSSFRow row = sh.getRow(x);
			XSSFCell cell = row.getCell(y);
			result =Double.toString(cell.getNumericCellValue());
			
		}
		catch(Exception e)
		{
			System.out.println(e);
			System.out.println("not reading");
		}
		
		return result;
	
	}

	public void create_log(String meth_name, String s1, String s2, String result) {
		// TODO Auto-generated method stub
		log=Logger.getLogger("devpinoyLogger");
		if(result.compareTo("PASS")==0)
		{
			if(s1=="")
				log.info("Method "+ meth_name+" executed \n");
			else
				log.info("Method "+ meth_name+" executed \n"+"Expected Result: "+s1+"\n Actual Result: "+s2+"\n Test Result: "+result);

		}
		else {
			if(s1=="")
				log.info("Method "+ meth_name+"\n");
			else
				log.info("Method "+ meth_name+"\n"+"Expected Result: "+s1+"\n Actual Result: "+s2+"\n Test Result: "+result);
		}
	}

	
	

}
