package Testng_pkg;

import java.util.ArrayList;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Base_class.Home_page;

public class NewTest1 {
	WebDriver dr;
	Home_page hp;
	@BeforeClass
	  public void entry() 
	 {
		   System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		   dr=new ChromeDriver();
		   dr.get("http://examples.codecharge.com/Store/Default.php"); 
		   
	  }
	  @AfterClass
	  public void exit()
	  {
		  dr.quit();
	  }
	@Test(priority=0)
	 public void verify_title()
	 {
		  hp=new Home_page(dr);
		  String s1=hp.title();
		  Assert.assertEquals(s1, "Online Bookstore");
	 }
	@Test(priority=1)
	  public void verify_search_product()
	  {
		  hp=new Home_page(dr);
		  String s1=hp.search_product();
		  Assert.assertEquals(s1, "Search Products");
	  }
}
