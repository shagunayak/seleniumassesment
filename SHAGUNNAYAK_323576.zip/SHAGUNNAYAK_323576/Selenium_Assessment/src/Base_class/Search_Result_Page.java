package Base_class;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Search_Result_Page {
	WebDriver dr;
	By xp=By.xpath("/html/body/table[5]/tbody/tr/td/table[2]/tbody/tr[1]/td[2]/b/a");
	public Search_Result_Page(WebDriver dr)
	{
		this.dr=dr;
	}
	public String title()
	{
		return dr.getTitle();
	} 
	public void click()
	{
		WebDriverWait wt = new WebDriverWait(dr,10);                             
		wt.until(ExpectedConditions.elementToBeClickable(xp));
		dr.findElement(xp).click();
	}
}
